<?php
namespace App\Models;
use App\Core\Model;
use App\Core\Field;
use App\Validators\StringValidator;
use App\Validators\NumberValidator;
class CategoryModel extends Model {
    protected function tableName(): string { return 'categories'; }
    protected function pkName(): string { return 'id'; }
    protected function getFields(): array {
        return [
            'id'   => new Field((new NumberValidator())->setMin(1), false),
            'name' => new Field((new StringValidator())->setMinLength(2)->setMaxLength(100)),
        ];
    }
}
