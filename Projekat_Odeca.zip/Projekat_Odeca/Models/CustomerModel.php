<?php
namespace App\Models;

use App\Core\Model;
use App\Core\Field;
use App\Validators\StringValidator;
use App\Validators\NumberValidator;
use App\Validators\EmailValidator;

class CustomerModel extends Model {
    protected function tableName(): string { return 'customers'; }
    protected function pkName(): string { return 'id'; }

    protected function getFields(): array {
        return [
            'id'        => new Field((new NumberValidator())->setMin(1), false),
            'full_name' => new Field((new StringValidator())->setMinLength(2)->setMaxLength(150)),
            'email'     => new Field(new EmailValidator()),
            'address'   => new Field((new StringValidator())->setMinLength(2)->setMaxLength(200)),
            'password'  => new Field((new StringValidator())->setMinLength(3)->setMaxLength(255)),
        ];
    }
}