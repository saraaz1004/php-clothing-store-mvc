<?php
namespace App\Models;
use App\Core\Model;
use App\Core\Field;
use App\Validators\StringValidator;
use App\Validators\NumberValidator;
class AdminModel extends Model {
    protected function tableName(): string { return 'admins'; }
    protected function pkName(): string { return 'id'; }
    protected function getFields(): array {
        return [
            'id'       => new Field((new NumberValidator())->setMin(1), false),
            'username' => new Field((new StringValidator())->setMinLength(3)->setMaxLength(100)),
            'password' => new Field((new StringValidator())->setMinLength(3)->setMaxLength(255)),
        ];
    }
}
