<?php
namespace App\Models;
use App\Core\Model;
use App\Core\Field;
use App\Validators\NumberValidator;
use App\Validators\StringValidator;
use PDO;
class OrderModel extends Model {
    protected function tableName(): string { return 'orders'; }
    protected function pkName(): string { return 'id'; }
    protected function getFields(): array {
        return [
            'id'          => new Field((new NumberValidator())->setMin(1), false),
            'customer_id' => new Field((new NumberValidator())->setMin(1)),
            'product_id'  => new Field((new NumberValidator())->setMin(1)),
            'order_date'  => new Field((new StringValidator())->setMinLength(10)->setMaxLength(10)),
            'quantity'    => new Field((new NumberValidator())->setMin(1)),
            'total_price' => new Field((new NumberValidator())->setMin(1)),
        ];
    }

    public function getAllDetailed(): array {
        $sql = 'SELECT o.*, cu.full_name, p.name AS product_name
                FROM orders o
                JOIN customers cu ON o.customer_id = cu.id
                JOIN products p ON o.product_id = p.id
                ORDER BY o.id DESC';
        $prep = $this->getDatabaseConnection()->getConnection()->prepare($sql);
        $prep->execute();
        return $prep->fetchAll(PDO::FETCH_OBJ);
    }

    public function countByCustomer(): array {
        $sql = 'SELECT cu.full_name, COUNT(o.id) AS broj_porudzbina
                FROM customers cu
                LEFT JOIN orders o ON cu.id = o.customer_id
                GROUP BY cu.id, cu.full_name';
        $prep = $this->getDatabaseConnection()->getConnection()->prepare($sql);
        $prep->execute();
        return $prep->fetchAll(PDO::FETCH_OBJ);
    }

    public function totalRevenue(): float {
        $sql = 'SELECT SUM(total_price) AS ukupna_zarada FROM orders';
        $prep = $this->getDatabaseConnection()->getConnection()->prepare($sql);
        $prep->execute();
        $item = $prep->fetch(PDO::FETCH_OBJ);
        return floatval($item->ukupna_zarada ?? 0);
    }
    public function getTopCustomer(): ?\stdClass {
        $sql = 'SELECT c.full_name, COUNT(o.id) AS broj_porudzbina
            FROM orders o
            JOIN customers c ON o.customer_id = c.id
            GROUP BY c.id
            ORDER BY broj_porudzbina DESC
            LIMIT 1';

        $prep = $this->getDatabaseConnection()->getConnection()->prepare($sql);
        $prep->execute();

        $result = $prep->fetch(\PDO::FETCH_OBJ);
        return $result ?: null;
    }
}
