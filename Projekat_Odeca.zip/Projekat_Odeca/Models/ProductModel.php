<?php
namespace App\Models;

use App\Core\Model;
use App\Core\Field;
use App\Validators\StringValidator;
use App\Validators\NumberValidator;
use PDO;

class ProductModel extends Model {
    protected function tableName(): string { return 'products'; }
    protected function pkName(): string { return 'id'; }

    protected function getFields(): array {
        return [
            'id'          => new Field((new NumberValidator())->setMin(1), false),
            'name'        => new Field((new StringValidator())->setMinLength(2)->setMaxLength(150)),
            'category_id' => new Field((new NumberValidator())->setMin(1)),
            'brand_id'    => new Field((new NumberValidator())->setMin(1)),
            'size'        => new Field((new StringValidator())->setMinLength(1)->setMaxLength(20)),
            'color'       => new Field((new StringValidator())->setMinLength(2)->setMaxLength(50)),
            'price'       => new Field((new NumberValidator())->setMin(1)),
            'quantity'    => new Field((new NumberValidator())->setMin(0)),
        ];
    }

    public function getAllWithCategoryAndBrand(): array {
        $sql = 'SELECT p.*, c.name AS category_name, b.name AS brand_name
                FROM products p
                JOIN categories c ON p.category_id = c.id
                JOIN brands b ON p.brand_id = b.id
                ORDER BY p.id DESC';
        $prep = $this->getDatabaseConnection()->getConnection()->prepare($sql);
        $prep->execute();
        return $prep->fetchAll(PDO::FETCH_OBJ);
    }

    public function getByCategoryId(int $categoryId): array {
        $sql = 'SELECT p.*, c.name AS category_name, b.name AS brand_name
                FROM products p
                JOIN categories c ON p.category_id = c.id
                JOIN brands b ON p.brand_id = b.id
                WHERE p.category_id = ?
                ORDER BY p.id DESC';
        $prep = $this->getDatabaseConnection()->getConnection()->prepare($sql);
        $prep->execute([$categoryId]);
        return $prep->fetchAll(PDO::FETCH_OBJ);
    }

    public function getMostExpensive(): ?\stdClass {
        $sql = 'SELECT * FROM products ORDER BY price DESC LIMIT 1';
        $prep = $this->getDatabaseConnection()->getConnection()->prepare($sql);
        $prep->execute();
        $item = $prep->fetch(PDO::FETCH_OBJ);
        return $item ?: null;
    }

    public function countByCategory(): array {
        $sql = 'SELECT c.name, COUNT(p.id) AS broj_proizvoda
                FROM categories c
                LEFT JOIN products p ON p.category_id = c.id
                GROUP BY c.id, c.name';
        $prep = $this->getDatabaseConnection()->getConnection()->prepare($sql);
        $prep->execute();
        return $prep->fetchAll(PDO::FETCH_OBJ);
    }

    public function deleteById(int $id): bool {
        $connection = $this->getDatabaseConnection()->getConnection();

        $connection->beginTransaction();

        try {
            $prep1 = $connection->prepare('DELETE FROM orders WHERE product_id = ?');
            $prep1->execute([$id]);

            $prep2 = $connection->prepare('DELETE FROM products WHERE id = ?');
            $prep2->execute([$id]);

            $connection->commit();
            return true;
        } catch (\Throwable $e) {
            $connection->rollBack();
            throw $e;
        }
    }

    public function totalQuantity(): int {
        $sql = 'SELECT SUM(quantity) AS total FROM products';
        $prep = $this->getDatabaseConnection()->getConnection()->prepare($sql);
        $prep->execute();
        $result = $prep->fetch(PDO::FETCH_OBJ);

        return (int)($result->total ?? 0);
    }
}