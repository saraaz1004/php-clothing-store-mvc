<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Models\ProductModel;

class CartController extends Controller {

    public function add($productId): void {
        $productId = (int)$productId;
        $quantity = (int)(filter_input(INPUT_POST, 'quantity', FILTER_SANITIZE_NUMBER_INT) ?? 1);

        if ($quantity < 1) {
            $quantity = 1;
        }

        $productModel = new ProductModel($this->getDatabaseConnection());
        $product = $productModel->getById($productId);

        if (!$product) {
            $this->redirect('product/all');
        }

        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }

        if (!isset($_SESSION['cart'][$productId])) {
            $_SESSION['cart'][$productId] = 0;
        }

        $_SESSION['cart'][$productId] += $quantity;

        $this->redirect('cart/view');
    }

    public function view(): void {
        $cart = $_SESSION['cart'] ?? [];
        $items = [];
        $total = 0;

        if (!empty($cart)) {
            $productModel = new ProductModel($this->getDatabaseConnection());

            foreach ($cart as $productId => $quantity) {
                $product = $productModel->getById((int)$productId);

                if (!$product) {
                    continue;
                }

                $subtotal = $product->price * $quantity;
                $total += $subtotal;

                $items[] = (object)[
                    'id' => $product->id,
                    'name' => $product->name,
                    'price' => $product->price,
                    'quantity' => $quantity,
                    'subtotal' => $subtotal,
                ];
            }
        }

        $this->set('items', $items);
        $this->set('total', $total);
    }

    public function remove($productId): void {
        $productId = (int)$productId;

        if (isset($_SESSION['cart'][$productId])) {
            unset($_SESSION['cart'][$productId]);
        }

        $this->redirect('cart/view');
    }

    public function clear(): void {
        unset($_SESSION['cart']);
        $this->redirect('cart/view');
    }
    public function checkout(): void {
        if (empty($_SESSION['customer_id'])) {
            $this->redirect('customer/login');
        }

        $cart = $_SESSION['cart'] ?? [];
        if (empty($cart)) {
            $this->redirect('cart/view');
        }

        $productModel = new \App\Models\ProductModel($this->getDatabaseConnection());
        $orderModel = new \App\Models\OrderModel($this->getDatabaseConnection());

        foreach ($cart as $productId => $quantity) {
            $product = $productModel->getById((int)$productId);

            if (!$product) {
                continue;
            }

            $totalPrice = $product->price * $quantity;

            $orderModel->add([
                'customer_id' => $_SESSION['customer_id'],
                'product_id' => $product->id,
                'order_date' => date('Y-m-d'),
                'quantity' => $quantity,
                'total_price' => $totalPrice,
            ]);
        }

        unset($_SESSION['cart']);
        $this->redirect('cart/view');
    }
}
