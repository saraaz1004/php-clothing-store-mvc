<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Models\ProductModel;
use App\Models\CategoryModel;

class ProductController extends Controller {

    public function getAll(): void {
        $model = new ProductModel($this->getDatabaseConnection());
        $this->set('products', $model->getAllWithCategoryAndBrand());
    }

    public function getByCategory($categoryId): void {
        $model = new ProductModel($this->getDatabaseConnection());
        $categoryModel = new CategoryModel($this->getDatabaseConnection());

        $this->set('products', $model->getByCategoryId((int)$categoryId));
        $this->set('category', $categoryModel->getById((int)$categoryId));
    }

    public function getStatistics(): void {
        $this->requireAdmin();

        $model = new ProductModel($this->getDatabaseConnection());

        $this->set('mostExpensive', $model->getMostExpensive());
        $this->set('counts', $model->countByCategory());
        $this->set('totalQuantity', $model->totalQuantity()); // 👈 OVO JE BITNO
    }
}