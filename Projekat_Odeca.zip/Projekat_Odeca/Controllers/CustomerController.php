<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Models\CustomerModel;

class CustomerController extends Controller {

    public function getRegister(): void {
        $this->set('message', '');
    }

    public function postRegister(): void {
        $fullName = trim(filter_input(INPUT_POST, 'full_name', FILTER_SANITIZE_FULL_SPECIAL_CHARS) ?? '');
        $email = trim(filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL) ?? '');
        $address = trim(filter_input(INPUT_POST, 'address', FILTER_SANITIZE_FULL_SPECIAL_CHARS) ?? '');
        $password = trim(filter_input(INPUT_POST, 'password', FILTER_SANITIZE_FULL_SPECIAL_CHARS) ?? '');

        if ($fullName === '' || $email === '' || $address === '' || $password === '') {
            $this->set('message', 'Sva polja su obavezna.');
            return;
        }

        $customerModel = new CustomerModel($this->getDatabaseConnection());
        $existing = $customerModel->getByField('email', $email);

        if ($existing) {
            $this->set('message', 'Kupac sa tim email-om već postoji.');
            return;
        }

        $customerModel->add([
            'full_name' => $fullName,
            'email' => $email,
            'address' => $address,
            'password' => $password,
        ]);

        $this->redirect('customer/login');
    }

    public function getLogin(): void {
        $this->set('message', '');
    }

    public function postLogin(): void {
        $email = trim(filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL) ?? '');
        $password = trim(filter_input(INPUT_POST, 'password', FILTER_SANITIZE_FULL_SPECIAL_CHARS) ?? '');

        $customerModel = new CustomerModel($this->getDatabaseConnection());
        $customer = $customerModel->getByField('email', $email);

        if (!$customer || $customer->password !== $password) {
            $this->set('message', 'Pogrešan email ili lozinka.');
            return;
        }

        $_SESSION['customer_id'] = $customer->id;
        $_SESSION['customer_name'] = $customer->full_name;

        $this->redirect('');
    }

    public function logout(): void {
        unset($_SESSION['customer_id'], $_SESSION['customer_name'], $_SESSION['cart']);
        $this->redirect('');
    }
}
