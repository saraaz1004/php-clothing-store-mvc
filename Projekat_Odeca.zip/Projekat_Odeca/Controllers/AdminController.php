<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Models\ProductModel;
use App\Models\OrderModel;

class AdminController extends Controller {

    public function getLogin(): void {
        $this->set('message', '');
    }

    public function postLogin(): void {
        $username = trim(filter_input(INPUT_POST, 'username', FILTER_SANITIZE_FULL_SPECIAL_CHARS) ?? '');
        $password = trim(filter_input(INPUT_POST, 'password', FILTER_SANITIZE_FULL_SPECIAL_CHARS) ?? '');

        $adminModel = new \App\Models\AdminModel($this->getDatabaseConnection());
        $admin = $adminModel->getByField('username', $username);

        if (!$admin || $admin->password !== $password) {
            $this->set('message', 'Pogresno korisnicko ime ili lozinka.');
            return;
        }

        $_SESSION['admin_id'] = $admin->id;
        $_SESSION['admin_username'] = $admin->username;

        unset($_SESSION['cart']);

        $this->redirect('admin/dashboard');
    }

    public function logout(): void {
        session_destroy();
        $this->redirect('');
    }

    public function dashboard(): void {
        $this->requireAdmin();

        $productModel = new ProductModel($this->getDatabaseConnection());
        $orderModel = new OrderModel($this->getDatabaseConnection());

        $this->set('productCount', count($productModel->getAll()));
        $this->set('orderCount', count($orderModel->getAll()));
        $this->set('revenue', $orderModel->totalRevenue());
    }

    public function getAddProduct(): void {
        $this->requireAdmin();

        $this->set('message', '');
        $this->set('categories', (new \App\Models\CategoryModel($this->getDatabaseConnection()))->getAll());
        $this->set('brands', (new \App\Models\BrandModel($this->getDatabaseConnection()))->getAll());
    }

    public function postAddProduct(): void {
        $this->requireAdmin();

        $name = trim(filter_input(INPUT_POST, 'name', FILTER_SANITIZE_FULL_SPECIAL_CHARS) ?? '');
        $categoryId = (int)(filter_input(INPUT_POST, 'category_id', FILTER_SANITIZE_NUMBER_INT) ?? 0);
        $brandId = (int)(filter_input(INPUT_POST, 'brand_id', FILTER_SANITIZE_NUMBER_INT) ?? 0);
        $size = trim(filter_input(INPUT_POST, 'size', FILTER_SANITIZE_FULL_SPECIAL_CHARS) ?? '');
        $color = trim(filter_input(INPUT_POST, 'color', FILTER_SANITIZE_FULL_SPECIAL_CHARS) ?? '');
        $price = (float)(filter_input(INPUT_POST, 'price', FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION) ?? 0);
        $quantity = (int)(filter_input(INPUT_POST, 'quantity', FILTER_SANITIZE_NUMBER_INT) ?? 0);

        try {
            $model = new ProductModel($this->getDatabaseConnection());
            $model->add([
                'name' => $name,
                'category_id' => $categoryId,
                'brand_id' => $brandId,
                'size' => $size,
                'color' => $color,
                'price' => $price,
                'quantity' => $quantity,
            ]);

            $this->redirect('product/all');
        } catch (\Throwable $e) {
            $this->set('message', 'Greska: ' . $e->getMessage());
            $this->set('categories', (new \App\Models\CategoryModel($this->getDatabaseConnection()))->getAll());
            $this->set('brands', (new \App\Models\BrandModel($this->getDatabaseConnection()))->getAll());
        }
    }

    public function deleteProduct($id): void {
        $this->requireAdmin();

        $productModel = new \App\Models\ProductModel($this->getDatabaseConnection());
        $productModel->deleteById((int)$id);

        $this->redirect('product/all');
    }
}