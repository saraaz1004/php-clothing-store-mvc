<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Models\OrderModel;

class OrderController extends Controller {
    public function getAll(): void {
        $this->requireAdmin();

        $model = new OrderModel($this->getDatabaseConnection());
        $this->set('orders', $model->getAllDetailed());
    }

    public function getStatistics(): void {
        $this->requireAdmin();

        $model = new OrderModel($this->getDatabaseConnection());

        $this->set('counts', $model->countByCustomer());
        $this->set('totalRevenue', $model->totalRevenue());
        $this->set('topCustomer', $model->getTopCustomer()); // 👈 NOVO
    }
}
