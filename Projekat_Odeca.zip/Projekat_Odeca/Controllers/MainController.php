<?php
namespace App\Controllers;
use App\Core\Controller;
use App\Models\CategoryModel;
class MainController extends Controller {
    public function home(): void {
        $categoryModel = new CategoryModel($this->getDatabaseConnection());
        $this->set('categories', $categoryModel->getAll());
    }
}
