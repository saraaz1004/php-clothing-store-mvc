<?php
namespace App\Validators;
use App\Core\Validator;
class StringValidator extends Validator {
    private int $minLength = 0;
    private int $maxLength = 255;
    public function setMinLength(int $value): self { $this->minLength = $value; return $this; }
    public function setMaxLength(int $value): self { $this->maxLength = $value; return $this; }
    public function isValid($value): bool {
        if (!is_string($value)) return false;
        $length = mb_strlen(trim($value));
        return $length >= $this->minLength && $length <= $this->maxLength;
    }
}
