<?php
namespace App\Validators;
use App\Core\Validator;
class NumberValidator extends Validator {
    private ?float $min = null;
    public function setMin(float $value): self { $this->min = $value; return $this; }
    public function isValid($value): bool {
        if (!is_numeric($value)) return false;
        if ($this->min !== null && $value < $this->min) return false;
        return true;
    }
}
