<?php
namespace App\Validators;
use App\Core\Validator;
class EmailValidator extends Validator {
    public function isValid($value): bool { return filter_var($value, FILTER_VALIDATE_EMAIL) !== false; }
}
