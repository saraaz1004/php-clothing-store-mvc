<?php
namespace App\Core;
use PDO;
abstract class Model {
    public function __construct(private DatabaseConnection $dbc) {}
    protected function getDatabaseConnection(): DatabaseConnection { return $this->dbc; }
    protected function getFields(): array { return []; }
    protected function tableName(): string { return ''; }
    protected function pkName(): string { return ''; }

    public function getAll(): array {
        $sql = 'SELECT * FROM ' . $this->tableName() . ' ORDER BY ' . $this->pkName() . ' DESC';
        $prep = $this->dbc->getConnection()->prepare($sql);
        $prep->execute();
        return $prep->fetchAll(PDO::FETCH_OBJ);
    }

    public function getById(int $id): ?\stdClass {
        $sql = 'SELECT * FROM ' . $this->tableName() . ' WHERE ' . $this->pkName() . ' = ?';
        $prep = $this->dbc->getConnection()->prepare($sql);
        $prep->execute([$id]);
        $item = $prep->fetch(PDO::FETCH_OBJ);
        return $item ?: null;
    }

    public function add(array $data): int {
        $fields = $this->getFields();
        foreach ($data as $name => $value) {
            if (!isset($fields[$name])) throw new \Exception('Nepodrzano polje: ' . $name);
            if (!$fields[$name]->isEditable()) throw new \Exception('Polje nije izmenljivo: ' . $name);
            if (!$fields[$name]->isFieldValueValid($value)) throw new \Exception('Neispravna vrednost za: ' . $name);
        }
        $columns = array_keys($data);
        $placeholders = implode(', ', array_fill(0, count($columns), '?'));
        $sql = 'INSERT INTO ' . $this->tableName() . ' (' . implode(', ', $columns) . ') VALUES (' . $placeholders . ')';
        $prep = $this->dbc->getConnection()->prepare($sql);
        $prep->execute(array_values($data));
        return intval($this->dbc->getConnection()->lastInsertId());
    }

    public function getByField(string $fieldName, $value): ?\stdClass {
        $sql = 'SELECT * FROM ' . $this->tableName() . ' WHERE ' . $fieldName . ' = ? LIMIT 1';
        $prep = $this->dbc->getConnection()->prepare($sql);
        $prep->execute([$value]);
        $item = $prep->fetch(PDO::FETCH_OBJ);
        return $item ?: null;
    }
}
