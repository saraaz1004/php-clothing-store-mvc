<?php
namespace App\Core;
class Route {
    public function __construct(
        private string $httpMethod,
        private string $pattern,
        private string $controllerName,
        private string $methodName
    ) {}
    public static function get($pattern, $controllerName, $methodName): Route { return new Route('GET', $pattern, $controllerName, $methodName); }
    public static function post($pattern, $controllerName, $methodName): Route { return new Route('POST', $pattern, $controllerName, $methodName); }
    public function matches($httpMethod, $url): bool {
        return preg_match('/^' . $this->httpMethod . '$/', $httpMethod) && preg_match($this->pattern, $url);
    }
    public function getControllerName(): string { return $this->controllerName; }
    public function getMethodName(): string { return $this->methodName; }
    public function extractArguments($url): array {
        preg_match_all($this->pattern, $url, $matches);
        unset($matches[0]);
        $arguments = [];
        foreach ($matches as $match) $arguments[] = $match[0];
        return $arguments;
    }
}
