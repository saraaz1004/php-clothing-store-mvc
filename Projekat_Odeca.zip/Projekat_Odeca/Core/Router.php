<?php
namespace App\Core;
class Router {
    private array $routes = [];
    public function add($route): void { $this->routes[] = $route; }
    public function find(string $httpMethod, string $url): ?Route {
        foreach ($this->routes as $route) {
            if ($route->matches($httpMethod, $url)) return $route;
        }
        return null;
    }
}
