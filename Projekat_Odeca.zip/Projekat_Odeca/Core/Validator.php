<?php
namespace App\Core;
abstract class Validator {
    abstract public function isValid($value): bool;
}
