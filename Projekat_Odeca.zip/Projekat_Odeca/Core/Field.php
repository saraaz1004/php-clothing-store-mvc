<?php
namespace App\Core;
class Field {
    public function __construct(
        private Validator $validator,
        private bool $editable = true
    ) {}
    public function isEditable(): bool { return $this->editable; }
    public function isFieldValueValid($value): bool { return $this->validator->isValid($value); }
}
