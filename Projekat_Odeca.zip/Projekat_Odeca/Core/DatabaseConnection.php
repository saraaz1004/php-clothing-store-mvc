<?php
namespace App\Core;
use PDO;
class DatabaseConnection {
    private PDO $connection;
    public function __construct(DatabaseConfiguration $config) {
        $this->connection = new PDO(
            'mysql:host=' . $config->host . ';dbname=' . $config->database . ';charset=utf8mb4',
            $config->username,
            $config->password,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );
    }
    public function getConnection(): PDO { return $this->connection; }
}
