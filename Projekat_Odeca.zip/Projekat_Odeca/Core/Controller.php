<?php
namespace App\Core;

class Controller {
    private array $data = [];

    public function __construct(private DatabaseConnection $dbc) {}

    final public function getDatabaseConnection(): DatabaseConnection {
        return $this->dbc;
    }

    final protected function set(string $name, $value): void {
        $this->data[$name] = $value; //za slanje podataka u view
    }

    final public function getData(): array {
        return $this->data; //vraca setovane podatke koristi se u index
    }

    final protected function redirect(string $path): void {
        header('Location: ' . \Configuration::BASE . 'index.php?URL=' . ltrim($path, '/'));
        exit;
    }

    final protected function requireAdmin(): void {
        if (empty($_SESSION['admin_id'])) {
            $this->redirect('admin/login');
        }
    }
}
