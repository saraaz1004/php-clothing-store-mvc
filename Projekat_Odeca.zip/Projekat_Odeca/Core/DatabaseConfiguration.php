<?php
namespace App\Core;
class DatabaseConfiguration {
    public function __construct(
        public string $host,
        public string $database,
        public string $username,
        public string $password
    ) {}
}
//cuva podatke za konekciju sa bazom
//koristi se u index